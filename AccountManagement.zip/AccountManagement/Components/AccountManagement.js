import React, { useState } from "react";
import TopNavigation from "../../../SharedModules/Layout/Components/TopNavigation";
import TabPanel from "../../../SharedModules/TabPanel/TabPanel";
import { makeStyles } from "@material-ui/core/styles";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import AppBar from "@material-ui/core/AppBar";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
import ScheduleIcon from "@material-ui/icons/Schedule";
import MessageIcon from "@material-ui/icons/Message";
import EmailIcon from "@material-ui/icons/Email";
import Email from "./Email";
import Login from "./Login";
import Message from "./Message";
import PasswordAndSession from "./PasswordAndSession";

function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    "aria-controls": `scrollable-auto-tabpanel-${index}`,
  };
}

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    width: "100%",
    backgroundColor: theme.palette.background.paper,
  },
}));

export default function AcountManagement() {
  const classes = useStyles();
  const [value, setValue] = useState(0);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <div id="reports" className="d-flex">
      <div>
        <TopNavigation isLoggedin={true} />
      </div>
      <div className="container-fluid px-4">
        <div className="py-3">
          <h2>Account Management</h2>
          <div className={classes.root}>
            <AppBar position="static" color="default">
              <Tabs
                value={value}
                onChange={handleChange}
                indicatorColor="primary"
                textColor="primary"
                variant="scrollable"
                scrollButtons="auto"
                aria-label="scrollable auto tabs example"
                backgroundColor="black"
              >
                <Tab
                  label="Login"
                  icon={<AccountCircleIcon />}
                  {...a11yProps(0)}
                  style={{ color: "teal !important" }}
                />
                <Tab
                  label="Password & Session"
                  icon={<ScheduleIcon />}
                  {...a11yProps(1)}
                  style={{ color: "teal" }}
                />
                <Tab
                  label="Message"
                  icon={<MessageIcon />}
                  {...a11yProps(2)}
                  style={{ color: "teal" }}
                />
                <Tab
                  label="Email"
                  icon={<EmailIcon />}
                  {...a11yProps(3)}
                  style={{ color: "teal" }}
                />
              </Tabs>
              <TabPanel value={value} index={0}>
                <Login />
              </TabPanel>
              <TabPanel value={value} index={1}>
                <PasswordAndSession />
              </TabPanel>
              <TabPanel value={value} index={2}>
                <Message />
              </TabPanel>
              <TabPanel value={value} index={3}>
                <Email />
              </TabPanel>
            </AppBar>
          </div>
        </div>
      </div>
    </div>
  );
}
