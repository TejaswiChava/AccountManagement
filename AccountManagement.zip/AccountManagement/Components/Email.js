import React from 'react';

export default function Email() {
    return (
        <>
            <h6>
                Email
            </h6>
        </>
    )
}