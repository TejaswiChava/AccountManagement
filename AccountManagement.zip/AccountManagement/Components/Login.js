import React from "react";
import TextField from "@material-ui/core/TextField";

export default function Login() {
  return (
    <>
      <div className="container-fluid mt-3 px-5">
        <div className="row">
          <div className="col-4">
            <TextField
              id="standard-full-width"
              label="CID"
              size="normal"
              style={{ margin: 8 }}
              fullWidth
              margin="normal"
              InputLabelProps={{
                shrink: true,
              }}
            />
          </div>
        </div>
      </div>
    </>
  );
}
