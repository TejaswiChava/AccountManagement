import React from 'react';


export default function Message() {
    return (
        <>
            <h6>Message</h6>
        </>
    )
}