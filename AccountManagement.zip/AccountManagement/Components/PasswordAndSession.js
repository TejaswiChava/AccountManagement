import React from 'react';


export default function PasswordAndSession() {
    return (
        <>
            <h6>Password and Session</h6>
        </>
    )
}